package rines_concesionario;

public interface IElegir {

    void elegirRin(int radio, int x, int y, int tamaño);
}
